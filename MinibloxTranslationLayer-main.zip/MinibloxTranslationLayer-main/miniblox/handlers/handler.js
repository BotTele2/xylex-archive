class Handler {
	constructor() { this.cleanup(); }
	miniblox() {}
	minecraft(client) {}
	cleanup() {}
	obtainHandlers(handler) {}
}

module.exports = Handler;