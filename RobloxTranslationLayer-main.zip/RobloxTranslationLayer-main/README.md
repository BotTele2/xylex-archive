# RobloxTranslationLayer
A middle man to translate Roblox gameplay into Minecraft 1.8.9 packets.

## Use Steps
1. Install the latest NodeJS at (https://nodejs.org/)
2. Download & extract the repository to a random folder
4. Move the client folder to the workspace of any exploit you choose
5. Move autoexec.lua into the autoexec folder of any exploit you choose
6. Open a terminal inside the previously extracted folder
7. Run npm install & node server.js
8. Launch roblox bedwars & inject the exploit you chose
9. Connect to localhost on a supported Minecraft 1.8.9 client

## Commands
/queue (stuff like bedwars_to2, skywars_to2, etc)
/buy (iron_sword, wool_white, iron_chestplate, etc)
/resync (respawns entities if they bug for any reason, idk)