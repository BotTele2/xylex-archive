return {
	[Color3.fromHex('#55FF55')] = 'a',
	[Color3.fromHex('#55FFFF')] = 'b',
	[Color3.fromHex('#FF5555')] = 'c',
	[Color3.fromHex('#FF55FF')] = 'd',
	[Color3.fromHex('#FFFF55')] = 'e',
	[Color3.fromHex('#FFFFFF')] = 'f',
	[Color3.fromHex('#000000')] = 0,
	[Color3.fromHex('#0000AA')] = 1,
	[Color3.fromHex('#00AA00')] = 2,
	[Color3.fromHex('#00AAAA')] = 3,
	[Color3.fromHex('#AA0000')] = 4,
	[Color3.fromHex('#AA00AA')] = 5,
	[Color3.fromHex('#FFAA00')] = 6,
	[Color3.fromHex('#AAAAAA')] = 7,
	[Color3.fromHex('#555555')] = 8,
	[Color3.fromHex('#5555FF')] = 9
}