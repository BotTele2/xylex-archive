class Handler {
	constructor() { this.cleanup(); }
	roblox() {}
	minecraft(client) {}
	cleanup() {}
	obtainHandlers(handler) {}
}

module.exports = Handler;