class Packet {
	encode(data) {}
    decode(data) {}
}

module.exports = Packet;