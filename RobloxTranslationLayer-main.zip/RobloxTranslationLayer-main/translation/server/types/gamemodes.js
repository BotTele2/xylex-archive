module.exports = {
    survival: 0,
    creative: 1,
    adventure: 2,
    spectator: 3
};