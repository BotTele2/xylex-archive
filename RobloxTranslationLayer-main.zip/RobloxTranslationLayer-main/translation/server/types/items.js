module.exports = {
    1: {id: 373, damage: 8194},
    2: {id: 310, name: 'Emerald Helmet', enchants:[[0, 1]]},
    3: {id: 311, name: 'Emerald Chestplate', enchants:[[0, 1]]},
    4: {id: 313, name: 'Emerald Boots', enchants:[[0, 1]]},
    5: {id: 276, name: 'Emerald Sword', enchants: [[16, 1]]},
    6: {id: 276, name: 'Rageblade', enchants: [[16, 2]]},
    7: {id: 280, name: 'Wood Crossbow', enchants: [[48, 1]]},
    8: {id: 280, name: 'Tactical Crossbow', enchants: [[48, 2]]},
    9: {id: 297, name: 'Knockback Baguette', enchants: [[19, 1]]}
};